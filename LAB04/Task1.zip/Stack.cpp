#include "Stack.h"
Stack::Stack()
{
	maxSize = 10;
	stackArray = new int[maxSize];
	stackTop = 0;
}

void Stack::Push(int a)
{
	if (stackTop<maxSize)
	{
		stackArray[stackTop] = a;
		stackTop += 1;
	}
}

int Stack::Pop()
{
	if (stackTop < maxSize && stackTop > 0)
	{
		stackTop -=1;
		return stackArray[stackTop];
	}
	return 0;
}