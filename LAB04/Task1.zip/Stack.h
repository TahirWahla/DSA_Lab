#pragma once
class Stack
{

	int * stackArray;
	int maxSize;
	int stackTop;
public:
	Stack();
	 void Push(int) ;
	
		int Pop();
	

};

