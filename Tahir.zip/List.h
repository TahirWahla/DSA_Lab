#pragma once
#include<iostream>
using namespace std;


//template
template<typename T>
void regrow(T*& arr, int current, int& max)
{
	T* temp = new T[max + 1];
	for (int i = 0; i < current; i++)
	{
		temp[i] = arr[i];
	}
	max += 1;
	delete[]arr;
	arr = temp;

}
//template
template<typename T>
void shrink(T*& arr, int current, int max)
{
	current -= 1;
	T* temp = new T[max - 1];
	for (int i = 0; i < current; i++)
	{
		temp[i] = arr[i];
	}
	max -= 1;
	delete[]arr;
	arr = temp;
}

//template
template<class T>
class List
{
	//Procted varible
protected:
	T* arr;
	int currentsiz;
	int maxsiz;
public:

	//Pure virtual funtions
	virtual void addElementAtFirstIndex(T a) = 0;
	virtual void removeElementFromSpecificPositionList(int) = 0;
	virtual void firstRepeatingElement() = 0; 
	virtual void firstNonRepeatingElement() = 0;
	virtual void findPairs() = 0;
	//	Should remove the element from the first position of the List

	//virtual function
	virtual	void display()
	{
		for (int i = 0; i < currentsiz; i++)
		{
			cout << arr[i] << " ";
		}
	}



	

};

