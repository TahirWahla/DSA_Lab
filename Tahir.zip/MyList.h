#pragma once
#include "List.h"
//template
template<class T>
//Public inharitance
class MyList :public List<T>
{



public:
	//constructor
	MyList(T a, int current, int max)
	{
		List<T>::maxsiz = max;
		List<T>::currentsiz = 0;
		regrow(List<T>::arr, List<T>::currentsiz, List<T>::maxsiz);
		List<T>::currentsiz += 1;
		List<T>::arr[0] = a;
	}

	T last()
	{
		return List<T>::arr[List<T>::currentsiz-1];
	}
	bool search(T a)
	{
		for (int i = 0; i < List<T>::currentsiz; i++)
		{
			if (a == List<T>::arr[i])
			{
				return true;
			}
		}
		return false;
	}
	bool insertAt(int index, T value)
	{
		if (index< List<T>::maxsiz)
		{
			List<T>::arr[index] = value;
				return true;
		}
		return false;
	}

	//override function
	void addElementAtFirstIndex(T a)
	{
		regrow(List<T>::arr, List<T>::currentsiz, List<T>::maxsiz);
		for (int i = List<T>::maxsiz - 1; i > 0; i--)
		{
			List<T>::arr[i] = List<T>::arr[i - 1];
		}
		List<T>::arr[0] = a;
		List<T>::currentsiz += 1;
	}

	//override function
	void removeElementFromSpecificPositionList(int index)
	{
		
		if (index<List<T>::currentsiz)
		{
			T* temp = new T[List<T>::maxsiz - 1];
			for (int i = 0, j = 0; i < List<T>::currentsiz;j++, i++)
			{
				if (i==index)
				{
					i++;
				}
				temp[j] = List<T>::arr[i];
			}
			
			
			List<T>::currentsiz -= 1;
			List<T>::maxsiz -= 1;
			delete[]List<T>::arr;
			List<T>::arr = temp;
			
		}
	}
	//override function
	void firstRepeatingElement()
	{
		int a = 0, counter = 0,current=0;
		for (int i = 0; i <List<T>::currentsiz; i++)
		{


			current = 0;
			

			for (int j = i+1; j < List<T>::currentsiz-1; j++)
			{
				if (List<T>::arr[i]==arr[j])
				{
					current += 1;
				}
			}
			if (counter<current)
			{
				counter = current;
				a = List<T>::arr[i];
			}
		}
		cout << a << endl;
	}
	//override function
	void firstNonRepeatingElement()
	{
		int a = 0, counter = 0, current = 0;
		for (int i = 0; i <List<T>::currentsiz; i++)
		{
			current = 0;
			for (int j = i + 1; j < List<T>::currentsiz - 1; j++)
			{
				if (List<T>::arr[i] == arr[j])
				{
					current += 1;
				}
			}
			if (current==0&& counter==0)
			{
				counter++;
				a = List<T>::arr[i];
			}
		}
		cout <<"Non Repeating number : " <<a << endl;
	}
	//override function
	void findPairs()
	{
		for (int i = 0; i <List<T>::currentsiz; i++)
		{
			
			for (int j = i + 1; j < List<T>::currentsiz - 1; j++)
			{
				if (List<T>::arr[i] + List<T>::arr[j]==7)
				{
					cout << List<T>::arr[i] << "," << List<T>::arr[j] << endl;
				}
			}
			
		}
	}


	//	Should remove the element from the first position of the List
	//override function
	void display()
	{
		for (int i = 0; i < List<T>::currentsiz; i++)
		{
			cout << List<T>::arr[i] << " ";
		}
	}


};

