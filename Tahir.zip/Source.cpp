#include"MyList.h"

int main()
{
	MyList<int> a('5',0,0);
	a.addElementAtFirstIndex('a');
	a.addElementAtFirstIndex('a');
	a.addElementAtFirstIndex('a');
	a.addElementAtFirstIndex('6');
	
	
	a.display();
	cout << endl;
	
	a.display();
	cout << endl;
	a.display();

	if (a.full())
	{
		cout << "Yesh" << endl;
	}

	if (a.insertAt(2,5))
	{
		cout << "Done" << endl;
	}
	a.display();

	if (a.search(97))
	{
		cout << "avalible" << endl;
	}

	cout << a.last() << endl;
	a.removeElementFromSpecificPositionList(2);
	cout << "Repeating number : ";
	a.firstRepeatingElement();
	a.firstNonRepeatingElement();
	a.findPairs();
	a.display();
	system("pause");
}